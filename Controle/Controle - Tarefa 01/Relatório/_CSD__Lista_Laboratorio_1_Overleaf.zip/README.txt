PROJETO LATEX PARA OVERLEAF

1. No Overleaf, selecione "New Project" > "Upload Project".
2. Envie o arquivo Lista_Laboratorio_1_Overleaf.zip.
3. O arquivo principal do projeto e main.tex.
4. Use o compilador pdfLaTeX.

Os logotipos utilizados no documento estão na pasta images.
